package de.meinetastatur

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class AiProfile(
    val name: String,
    val emoji: String,
    val prompt: String
)

object ProfileStore {
    private const val PREFS = "keyboard_prefs"
    private const val KEY_PROFILES = "profiles"
    private const val KEY_API = "gemini_key"
    private const val KEY_THEME = "theme"
    private const val KEY_HAPTIC = "haptic"
    private const val KEY_SUGGESTIONS = "suggestions"
    private const val KEY_AUTOCAP = "autocap"
    private const val KEY_NUMBER_ROW = "number_row"

    fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun apiKey(context: Context): String = prefs(context).getString(KEY_API, "") ?: ""
    fun saveApiKey(context: Context, value: String) {
        prefs(context).edit().putString(KEY_API, value.trim()).apply()
    }

    fun theme(context: Context): String = prefs(context).getString(KEY_THEME, "dark") ?: "dark"
    fun saveTheme(context: Context, value: String) {
        prefs(context).edit().putString(KEY_THEME, value).apply()
    }

    fun haptics(context: Context) = prefs(context).getBoolean(KEY_HAPTIC, true)
    fun suggestions(context: Context) = prefs(context).getBoolean(KEY_SUGGESTIONS, true)
    fun autoCap(context: Context) = prefs(context).getBoolean(KEY_AUTOCAP, true)
    fun numberRow(context: Context) = prefs(context).getBoolean(KEY_NUMBER_ROW, false)

    fun setBoolean(context: Context, key: String, value: Boolean) {
        prefs(context).edit().putBoolean(key, value).apply()
    }

    fun profiles(context: Context): MutableList<AiProfile> {
        val raw = prefs(context).getString(KEY_PROFILES, null)
        if (raw.isNullOrBlank()) {
            return mutableListOf(
                AiProfile("Freundlicher", "😊", "Schreibe den Text freundlich und natürlich um. Behalte die Bedeutung bei."),
                AiProfile("Professionell", "💼", "Formuliere den Text professionell, klar und höflich. Behalte die Bedeutung bei."),
                AiProfile("Kürzer", "⚡", "Kürze den Text deutlich, ohne wichtige Informationen zu verlieren.")
            )
        }
        return try {
            val array = JSONArray(raw)
            MutableList(array.length()) { i ->
                val obj = array.getJSONObject(i)
                AiProfile(obj.optString("name", "Profil"), obj.optString("emoji", "✨"), obj.optString("prompt", "Schreibe den Text besser."))
            }
        } catch (_: Exception) {
            mutableListOf(AiProfile("Freundlicher", "😊", "Schreibe den Text freundlich um."))
        }
    }

    fun saveProfiles(context: Context, profiles: List<AiProfile>) {
        val array = JSONArray()
        profiles.take(10).forEach {
            array.put(JSONObject().put("name", it.name).put("emoji", it.emoji).put("prompt", it.prompt))
        }
        prefs(context).edit().putString(KEY_PROFILES, array.toString()).apply()
    }
}
