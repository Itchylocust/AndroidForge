package de.meinetastatur

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(title: String): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            setBackgroundColor(Color.rgb(17, 17, 19))
        }
        root.addView(TextView(this).apply {
            text = title; textSize = 25f; setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(16)); typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        return root
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun add(root: LinearLayout, view: android.view.View) {
        root.addView(view, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }

    private fun showHome() {
        val root = base("Meine Tastatur  ✨")
        add(root, TextView(this).apply {
            text = "Deine eigene QWERTZ-Tastatur mit KI-Profilen. Die Tastatur funktioniert auch ohne KI-Key."
            textSize = 16f; setTextColor(Color.LTGRAY)
        })
        add(root, button("1. Tastatur aktivieren") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        add(root, button("2. Tastatur auswählen") {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        add(root, button("KI-Key und Optionen") { showSettings() })
        add(root, button("KI-Profile bearbeiten") { showProfiles() })
        add(root, TextView(this).apply {
            text = "Datenschutz: Der KI-Key wird lokal auf diesem Gerät gespeichert. Text wird nur an den KI-Anbieter gesendet, wenn du ausdrücklich ein Profil auswählst."
            textSize = 13f; setTextColor(Color.GRAY); setPadding(0, dp(12), 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun showSettings() {
        val root = base("Einstellungen")
        add(root, TextView(this).apply {
            text = "Gemini API-Key (optional)"; setTextColor(Color.WHITE); textSize = 16f
        })
        val key = EditText(this).apply {
            hint = "API-Key hier einfügen"; setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE); inputType = 129
            setText(ProfileStore.apiKey(this@MainActivity))
        }
        add(root, key)
        add(root, button("Key lokal speichern") {
            ProfileStore.saveApiKey(this, key.text.toString())
            Toast.makeText(this, "Gespeichert", Toast.LENGTH_SHORT).show()
        })
        add(root, TextView(this).apply {
            text = "Ein kostenloses Kontingent ist vom Anbieter und Konto abhängig. Die App selbst verlangt kein Abo. Teile deinen Key mit niemandem."
            setTextColor(Color.LTGRAY); textSize = 13f
        })
        add(root, TextView(this).apply { text = "Design"; setTextColor(Color.WHITE); textSize = 16f })
        val themes = Spinner(this)
        themes.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Dunkel", "Hell"))
        themes.setSelection(if (ProfileStore.theme(this) == "light") 1 else 0)
        add(root, themes)
        add(root, button("Design speichern") {
            ProfileStore.saveTheme(this, if (themes.selectedItemPosition == 1) "light" else "dark")
            Toast.makeText(this, "Gespeichert – öffne die Tastatur erneut.", Toast.LENGTH_SHORT).show()
        })
        fun addSwitch(label: String, keyName: String, initial: Boolean) {
            val s = Switch(this).apply { text = label; setTextColor(Color.WHITE); isChecked = initial }
            s.setOnCheckedChangeListener { _, checked -> ProfileStore.setBoolean(this, keyName, checked) }
            add(root, s)
        }
        addSwitch("Vibration", "haptic", ProfileStore.haptics(this))
        addSwitch("Wortvorschläge", "suggestions", ProfileStore.suggestions(this))
        addSwitch("Automatische Großschreibung", "autocap", ProfileStore.autoCap(this))
        addSwitch("Zahlenreihe", "number_row", ProfileStore.numberRow(this))
        add(root, button("Zurück") { showHome() })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun showProfiles() {
        val root = base("KI-Profile (max. 10)")
        val list = ProfileStore.profiles(this)
        list.forEachIndexed { index, profile ->
            add(root, button("${profile.emoji}  ${profile.name}  ·  Bearbeiten") {
                editProfile(index, profile)
            })
        }
        if (list.size < 10) add(root, button("＋ Neues Profil") {
            editProfile(-1, AiProfile("Mein Profil", "✨", "Schreibe den Text gemäß dieser Anweisung um."))
        })
        add(root, button("Zurück") { showHome() })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun editProfile(index: Int, profile: AiProfile) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0)
        }
        val name = EditText(this).apply { hint = "Name"; setText(profile.name) }
        val emoji = EditText(this).apply { hint = "Emoji, z. B. 😊"; setText(profile.emoji) }
        val prompt = EditText(this).apply {
            hint = "Was soll die KI tun?"; setText(profile.prompt)
            minLines = 4; gravity = Gravity.TOP
        }
        box.addView(name); box.addView(emoji); box.addView(prompt)
        val options = arrayOf("Speichern", "Löschen", "Abbrechen")
        AlertDialog.Builder(this).setTitle("Profil bearbeiten").setView(box)
            .setPositiveButton("Speichern") { _, _ ->
                val list = ProfileStore.profiles(this)
                val new = AiProfile(name.text.toString().ifBlank { "Mein Profil" },
                    emoji.text.toString().ifBlank { "✨" }, prompt.text.toString().ifBlank { "Schreibe den Text besser." })
                if (index >= 0 && index < list.size) list[index] = new else if (list.size < 10) list.add(new)
                ProfileStore.saveProfiles(this, list)
                showProfiles()
            }
            .setNeutralButton(if (index >= 0) "Löschen" else "Abbrechen") { _, _ ->
                if (index >= 0) {
                    val list = ProfileStore.profiles(this)
                    if (index < list.size) list.removeAt(index)
                    ProfileStore.saveProfiles(this, list)
                    showProfiles()
                }
            }
            .setNegativeButton("Abbrechen", null).show()
    }
}
