package de.meinetastatur

import android.inputmethodservice.InputMethodService
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.HapticFeedbackConstants
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.util.concurrent.Executors

class MyKeyboardService : InputMethodService() {
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var shift = true
    private var symbols = false
    private var previewDialog: AlertDialog? = null
    private var pendingBefore = 0
    private var pendingAfter = 0
    private var pendingSelected = false
    private var pendingOriginal = ""
    private var pendingResult = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun light() = ProfileStore.theme(this) == "light"
    private fun bg() = if (light()) Color.rgb(239, 239, 243) else Color.rgb(18, 18, 20)
    private fun keyBg() = if (light()) Color.WHITE else Color.rgb(48, 48, 52)
    private fun fg() = if (light()) Color.rgb(25, 25, 28) else Color.WHITE
    private fun accent() = if (light()) Color.rgb(30, 90, 190) else Color.rgb(155, 125, 255)

    override fun onCreateInputView(): View = buildKeyboard()

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
    }

    private fun buildKeyboard(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(5), dp(4), dp(8))
            setBackgroundColor(bg())
        }
        val suggestions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "Meine Tastatur"; textSize = 12f; setTextColor(fg())
            gravity = Gravity.CENTER; setPadding(dp(4), 0, dp(4), 0)
        }
        suggestions.addView(title, LinearLayout.LayoutParams(0, dp(36), 1f))
        val ai = TextView(this).apply {
            text = "✨ AI"; textSize = 14f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setBackgroundColor(accent()); setPadding(dp(14), dp(7), dp(14), dp(7))
            setOnClickListener { showAiMenu() }
        }
        suggestions.addView(ai, LinearLayout.LayoutParams(-2, dp(34)))
        root.addView(suggestions)

        if (ProfileStore.numberRow(this)) addKeyRow(root, listOf("1","2","3","4","5","6","7","8","9","0"))

        val rows = if (symbols) listOf(
            listOf("1","2","3","4","5","6","7","8","9","0"),
            listOf("@","#","$","%","&","-","+","(",")","/"),
            listOf("= ", "*", "\"", "'", ":", ";", "!", "?", "⌫"),
            listOf("ABC", ",", "😊", "🌐", "Leer", ".", "↵")
        ) else listOf(
            listOf("q","w","e","r","t","z","u","i","o","p"),
            listOf("a","s","d","f","g","h","j","k","l"),
            listOf("⇧","y","x","c","v","b","n","m","⌫"),
            listOf("?123",",","😊","🌐","Leer",".","↵")
        )
        rows.forEach { row -> addKeyRow(root, row) }
        return root
    }

    private fun addKeyRow(root: LinearLayout, labels: List<String>) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
        }
        labels.forEach { label ->
            val wide = label in listOf("Leer", "⇧", "⌫", "↵", "?123", "ABC", "🌐")
            val key = TextView(this).apply {
                text = when (label) { "Leer" -> "Espacio"; else -> label }
                textSize = if (label.length > 1) 13f else 18f
                setTextColor(if (label == "↵") Color.WHITE else fg())
                gravity = Gravity.CENTER
                setBackgroundColor(if (label == "↵") accent() else keyBg())
                typeface = Typeface.DEFAULT
                setPadding(dp(2), 0, dp(2), 0)
                isClickable = true
                setOnClickListener { handleKey(label, this) }
            }
            val lp = LinearLayout.LayoutParams(0, dp(44), if (wide) 1.35f else 1f)
            lp.setMargins(dp(2), dp(3), dp(2), dp(3))
            row.addView(key, lp)
        }
        root.addView(row)
    }

    private fun handleKey(key: String, view: View) {
        if (ProfileStore.haptics(this)) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        val ic = currentInputConnection ?: return
        when (key) {
            "⇧" -> { shift = !shift; setInputView(buildKeyboard()) }
            "?123" -> { symbols = true; setInputView(buildKeyboard()) }
            "ABC" -> { symbols = false; setInputView(buildKeyboard()) }
            "⌫" -> {
                val selected = ic.getSelectedText(0)
                if (!selected.isNullOrEmpty()) ic.commitText("", 1)
                else ic.deleteSurroundingText(1, 0)
            }
            "↵" -> {
                val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
                if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) ic.performEditorAction(action)
                else ic.commitText("\n", 1)
            }
            "Leer" -> ic.commitText(" ", 1)
            "😊" -> showEmojiPicker()
            "🌐" -> (getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showInputMethodPicker()
            "," -> ic.commitText(",", 1)
            "." -> ic.commitText(".", 1)
            else -> {
                var out = key
                if (!symbols && shift) out = key.uppercase()
                ic.commitText(out, 1)
                if (shift && !symbols) { shift = false; setInputView(buildKeyboard()) }
            }
        }
    }

    private fun showEmojiPicker() {
        val emojis = listOf("😀","😂","🥹","😍","😎","😭","❤️","🔥","✨","👍","🙏","🥰","😅","🤔","🙄","💀")
        AlertDialog.Builder(this).setTitle("Emoji")
            .setItems(emojis.toTypedArray()) { _, which -> currentInputConnection?.commitText(emojis[which], 1) }
            .show()
    }

    private fun showAiMenu() {
        val profiles = ProfileStore.profiles(this)
        val labels = profiles.map { "${it.emoji}  ${it.name}" }.toMutableList()
        labels.add("⚙️  Einstellungen / Profile bearbeiten")
        AlertDialog.Builder(this)
            .setTitle("KI-Assistent")
            .setItems(labels.toTypedArray()) { _, which ->
                if (which == labels.lastIndex) {
                    val intent = packageManager.getLaunchIntentForPackage(packageName)
                    intent?.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                } else {
                    processWithProfile(profiles[which])
                }
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun processWithProfile(profile: AiProfile) {
        val ic = currentInputConnection
        if (ic == null) {
            Toast.makeText(this, "Kein Textfeld aktiv.", Toast.LENGTH_SHORT).show()
            return
        }
        val selected = ic.getSelectedText(0)?.toString()
        pendingSelected = !selected.isNullOrEmpty()
        if (pendingSelected) {
            pendingOriginal = selected!!
            pendingBefore = 0; pendingAfter = 0
        } else {
            val before = ic.getTextBeforeCursor(5000, 0)?.toString().orEmpty()
            val after = ic.getTextAfterCursor(5000, 0)?.toString().orEmpty()
            pendingOriginal = before + after
            pendingBefore = before.length
            pendingAfter = after.length
            if (pendingOriginal.isBlank()) {
                Toast.makeText(this, "Schreibe zuerst etwas Text.", Toast.LENGTH_SHORT).show()
                return
            }
        }
        val key = ProfileStore.apiKey(this)
        if (key.isBlank()) {
            AlertDialog.Builder(this)
                .setTitle("KI-Key fehlt")
                .setMessage("Die Tastatur funktioniert auch ohne Key. Für echte KI-Umschreibungen brauchst du einen API-Key, den du in den App-Einstellungen eintragen kannst. Dein Text wurde nicht verändert.")
                .setPositiveButton("OK", null).show()
            return
        }
        Toast.makeText(this, "KI arbeitet …", Toast.LENGTH_SHORT).show()
        executor.execute {
            try {
                val result = callGemini(key, profile.prompt, pendingOriginal)
                mainHandler.post { showPreview(result) }
            } catch (e: Exception) {
                mainHandler.post {
                    AlertDialog.Builder(this)
                        .setTitle("KI nicht erreichbar")
                        .setMessage("Dein Originaltext blieb unverändert.\n\n${e.message ?: "Unbekannter Fehler"}")
                        .setPositiveButton("OK", null).show()
                }
            }
        }
    }

    private fun callGemini(apiKey: String, prompt: String, text: String): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        try {
            val instruction = "$prompt\n\nGib nur den überarbeiteten Text zurück, ohne Anführungszeichen oder Erklärung.\n\nTEXT:\n$text"
            val body = JSONObject().put("contents", JSONArray().put(
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", instruction)))
            )).toString()
            OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(body) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code: ${response.take(400)}")
            val json = JSONObject(response)
            return json.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                .getString("text").trim().ifBlank { throw IllegalStateException("Leere Antwort") }
        } finally {
            connection.disconnect()
        }
    }

    private fun showPreview(result: String) {
        pendingResult = result
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0)
        }
        content.addView(TextView(this).apply {
            text = "Original"; setTextColor(Color.GRAY); textSize = 12f
        })
        content.addView(TextView(this).apply {
            text = pendingOriginal; setTextColor(fg()); textSize = 14f
            setPadding(0, 0, 0, dp(12))
        })
        content.addView(TextView(this).apply {
            text = "Vorschau"; setTextColor(accent()); textSize = 12f
        })
        val output = EditText(this).apply {
            setText(result); setTextColor(fg()); minLines = 3; gravity = Gravity.TOP
        }
        content.addView(output)
        previewDialog = AlertDialog.Builder(this)
            .setTitle("Text prüfen")
            .setView(content)
            .setPositiveButton("Übernehmen", null)
            .setNegativeButton("Abbrechen", null)
            .create()
        previewDialog?.setOnShowListener {
            previewDialog?.getButton(AlertDialog.BUTTON_POSITIVE)?.setOnClickListener {
                val replacement = output.text.toString()
                val ic = currentInputConnection
                if (ic != null) {
                    if (pendingSelected) {
                        ic.commitText(replacement, 1)
                    } else {
                        ic.beginBatchEdit()
                        ic.deleteSurroundingText(pendingBefore, pendingAfter)
                        ic.commitText(replacement, 1)
                        ic.endBatchEdit()
                    }
                }
                previewDialog?.dismiss()
            }
        }
        previewDialog?.show()
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
