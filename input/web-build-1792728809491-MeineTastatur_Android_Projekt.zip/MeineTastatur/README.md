# Meine Tastatur – Android-Projekt

Eine kostenlose, quelloffene Startversion einer echten Android-Tastatur (IME), mit:
- deutschem QWERTZ-Layout
- Umschaltung Groß-/Kleinschreibung und Symbolen
- Leerzeichen, Löschen, Enter, Emoji-Auswahl
- optionalen Wortvorschlägen-/Zahlenreihe-Einstellungen (Wortvorschläge sind in dieser ersten Version noch kein vollständiges Wörterbuch)
- bis zu 10 lokal gespeicherten KI-Profilen mit eigenem Namen, Emoji und Prompt
- Gemini API-Aufruf auf ausdrücklichen Profil-Tipp
- Vorschau mit Übernehmen/Abbrechen
- dunklem/hellem Theme
- keine Werbung, keine Analyse-SDKs und kein eingebauter API-Key

## Bauen auf dem Handy
1. Öffne dieses Projekt in einer Android-IDE, die Gradle/Kotlin-Projekte unterstützt (z. B. Code on the Go, sofern die aktuelle Version den verwendeten Android-Gradle-Plugin-Build unterstützt).
2. Lass Gradle synchronisieren und erstelle eine Debug-APK.
3. Installiere die APK.
4. Öffne die App → „Tastatur aktivieren“ → aktiviere „Meine Tastatur“.
5. Wähle „Tastatur auswählen“ → „Meine Tastatur“.
6. Optional: Trage deinen Gemini API-Key in den Einstellungen ein.

## Wichtig
- Dieses Projekt ist ein Startpunkt, keine Garantie, dass jede Handy-IDE den Build ohne Anpassungen schafft. Der Android Gradle Plugin-Build braucht ein passendes JDK (17) und Android SDK.
- Der API-Key wird lokal in App-Preferences gespeichert. Das ist bequemer, aber kein sicherer Geheimnisspeicher. Verwende keine Schlüssel mit Zugriff auf sensible oder kostenpflichtige Ressourcen und gib ihn niemals weiter.
- Kostenlose API-Kontingente hängen vom Anbieter, Modell, Land und Konto ab und können sich ändern. API-Aufrufe benötigen Internet und senden den Text, den du ausdrücklich zur Bearbeitung auswählst, an Google.
- Die Tastatur kann unabhängig vom KI-Dienst normal tippen. KI-Bearbeitung funktioniert nur mit gültigem API-Key und Internet.
- Für Apps mit Passwörtern, Zahlungsdaten oder vertraulichen Informationen solltest du diese Tastatur nicht verwenden, solange sie nicht gründlich getestet wurde.
